# Images folder

This Folder holds all assets for the game

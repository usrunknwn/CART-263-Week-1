# Mythic Clash

This is a webcam based game similar in style to Mortal Combat or Street Fighter, the game features two players who battle using different spells.
